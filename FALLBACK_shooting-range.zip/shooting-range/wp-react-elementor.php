<?php
/**
 * Elementor shooting-range WordPress Plugin
 *
 * @package ShootingRange
 *
 * Plugin Name: shooting-range
 * Description: 
 * Plugin URI:  
 * Version:     1.0.0
 * Author:      
 * Author URI:  
 * Text Domain: shooting-range
 */

define( 'ELEMENTOR_SHOOTING_RANGE', __FILE__ );

/**
 * Include the shooting-range class.
 */
require plugin_dir_path(ELEMENTOR_SHOOTING_RANGE) . 'class-react-elementor.php';
