// eslint-disable-next-line @typescript-eslint/no-unused-vars
import styles from './shooting-range.module.css';

export function App() {
  return (
    <div>
      <h1>
        <span> Hello there, </span>
        Welcome shooting-range 👋
      </h1>
    </div>
  );
}

export default App;
